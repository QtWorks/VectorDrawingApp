#pragma once

#include <vector>
#include "Types.h"
#include "export_dll.h"

using namespace std;

namespace RenderingEngine
{

	struct ShapeAttributes
	{
		int 		shapeType;
		int 		fillType;
		ColorRGB 	fillColor;
		int 		strokeType;
		ColorRGB 	strokeColor;
		float 		strokeWidth;
	};

	class RENDERINGENGINE_API Shape
	{
	public:
		Shape();
		Shape(ShapeAttributes data);
		~Shape(void);
		void load(FILE *f, int format);
		void save(FILE *f, int format);
		void createStart(int x, int y);
		void createProcessing(int x, int y);
		void createEnd(int x, int y);
		void drawContent();
		void setFillColor(COLORREF color);
		void setStrokeColor(COLORREF color);
		bool fillContainsPoint(int x, int y);
		void setSeleted(bool select);
		void moveRel(int relX, int relY);

		// File formats
		void load_0_0_1(FILE *stream);
		void save_0_0_1(FILE *stream);

	protected:
		void _initAttributes();
		void _createCommonObjects();
		void _createLineGeometry();
		void _createBrushGeometry();
		void _createBrushes();
		void _drawSelectionOutline(void);

	protected:
		ID2D1RenderTarget *m_pRenderTarget;
		ID2D1SolidColorBrush *m_selectionBrush;
		ID2D1SolidColorBrush *m_whiteBrush;
		ID2D1StrokeStyle *m_pStrokeStyleCustomOffsetZero;
		ID2D1StrokeStyle *m_pLineStrokeStyle;
		ID2D1SolidColorBrush *m_pStrokeBrush;
	    ID2D1SolidColorBrush *m_pFillBrush;

	public:
		// Shape Attributes
		int mType;
		int mFillType;
		ColorRGB mFillColor;
		int mStrokeType;
		ColorRGB mStrokeColor;
		float mStrokeWidth;

		// Geometry
		int mX;
		int mY;
		int mWidth;
		int mHeight;

		// Flags
		bool mSelected;
		bool mFirstDraw;
		bool mOnCreation;

		// Line
		D2D1_POINT_2F *mLineStart;
		D2D1_POINT_2F *mLineEnd;

		// Brush
		vector<D2D1_POINT_2F> *mPoints;

		// Rectangle
		ID2D1RectangleGeometry *mRectangleGeometry;
		
		// Ellipse
		ID2D1EllipseGeometry *mEllipseGeometry;

		// Line & Brush
		ID2D1PathGeometry *mPathGeometry;

		// Others
		int mOldX;
		int mOldY;
	};

}


