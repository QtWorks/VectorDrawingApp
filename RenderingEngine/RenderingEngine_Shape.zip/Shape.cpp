
#include "StdAfx.h"
#include "Shape.h"
#include <Windows.h>
#include "colorutil.h"

#include "Renderer.h"

using namespace RenderingEngine;

extern ID2D1RenderTarget 	*g_pRenderTarget;
extern ID2D1Factory			*g_pD2DFactory;

Shape::Shape()
{
	_initAttributes();
	_createCommonObjects();

	mPoints = new vector<D2D1_POINT_2F>;
}

Shape::Shape(ShapeAttributes data)
{
	HRESULT hr = S_OK;	

	_initAttributes();
	_createCommonObjects();

	mPoints = new vector<D2D1_POINT_2F>;

	// Initialize attributes from ShapeAttributes
	mType = data.shapeType;
	mFillType = data.fillType;
	mStrokeType = data.strokeType;
	mStrokeWidth = data.strokeWidth;
	mStrokeColor = data.strokeColor;
	mFillColor = data.fillColor;

	_createBrushes();
}

void Shape::_createBrushes()
{
	HRESULT hr;

	if(mStrokeType == Renderer::STROKETYPE_SOLID)
	{
	    hr = m_pRenderTarget->CreateSolidColorBrush(
			D2D1::ColorF(mStrokeColor.r, mStrokeColor.g, mStrokeColor.b),
	        &m_pStrokeBrush
	        );
	}

	if(mFillType == Renderer::FILLTYPE_SOLID)
	{
	    hr = m_pRenderTarget->CreateSolidColorBrush(
			D2D1::ColorF(mFillColor.r, mFillColor.g, mFillColor.b),  
	        &m_pFillBrush
	        );
	}
}

void Shape::save(FILE *f, int format)
{
	if(format == Renderer::FILE_FORMAT_0_0_1) save_0_0_1(f);
	
}

void Shape::load(FILE *f, int format)
{
	if(format == Renderer::FILE_FORMAT_0_0_1) load_0_0_1(f);
}

void Shape::load_0_0_1(FILE *f)
{
	_initAttributes();
	_createCommonObjects();

	// Load shape type
	fread(&mType, sizeof(int),1, f);

	// Save Attributes
	fread(&mFillType, sizeof(int),1, f);
	fread(&mFillColor, sizeof(ColorRGB),1, f);
	fread(&mStrokeType, sizeof(int),1, f);
	fread(&mStrokeColor, sizeof(ColorRGB),1, f);
	fread(&mStrokeWidth, sizeof(float),1, f);

	// Save Geometry
	fread(&mX, sizeof(int),1, f);
	fread(&mY, sizeof(int),1, f);
	fread(&mWidth, sizeof(int),1, f);
	fread(&mHeight, sizeof(int),1, f);

	_createBrushes();

	// Other shape specific attributes
	if(mType == Renderer::OBJECT_TYPE_LINE)
	{
		mLineStart = new D2D1_POINT_2F;
		mLineEnd = new D2D1_POINT_2F;

		fread(&mLineStart->x, sizeof(int),1, f);
		fread(&mLineStart->y, sizeof(int),1, f);
		fread(&mLineEnd->x, sizeof(int),1, f);
		fread(&mLineEnd->y, sizeof(int),1, f);

		_createLineGeometry();
	}
	else if(mType == Renderer::OBJECT_TYPE_BRUSH)
	{
		int pointsCount = 0;

		fread(&pointsCount, sizeof(int),1, f);
		for(int i=0; i<pointsCount; i++)
		{
			D2D1_POINT_2F point;
			FLOAT px, py;
			fread(&px, sizeof(FLOAT), 1, f);
			fread(&py, sizeof(FLOAT), 1, f);
			point.x = px;
			point.y = py;
			mPoints->push_back(point);
		}
		_createBrushGeometry();
	}

	mOnCreation = false;
	mFirstDraw = false;
}

void Shape::save_0_0_1(FILE *f)
{
	// Save shape type
	fwrite(&mType, sizeof(int), 1, f);

	// Save Attributes
	fwrite(&mFillType, sizeof(int), 1, f);
	fwrite(&mFillColor, sizeof(ColorRGB), 1, f);
	fwrite(&mStrokeType, sizeof(int), 1, f);
	fwrite(&mStrokeColor, sizeof(ColorRGB),1, f);
	fwrite(&mStrokeWidth, sizeof(float),1, f);

	// Save Geometry
	fwrite(&mX, sizeof(int), 1, f);
	fwrite(&mY, sizeof(int), 1, f);
	fwrite(&mWidth, sizeof(int), 1, f);
	fwrite(&mHeight, sizeof(int), 1, f);

	// Other shape specific attributes
	if(mType == Renderer::OBJECT_TYPE_LINE)
	{
		fwrite(&mLineStart->x, sizeof(int),1, f);
		fwrite(&mLineStart->y, sizeof(int),1, f);
		fwrite(&mLineEnd->x, sizeof(int),1, f);
		fwrite(&mLineEnd->y, sizeof(int),1, f);
	}
	else if(mType == Renderer::OBJECT_TYPE_BRUSH)
	{
		int pointsCount = mPoints->size();

		fwrite(&pointsCount, sizeof(int),1, f);
		for(int i=0; i<pointsCount; i++)
		{
			D2D1_POINT_2F point = mPoints->at(i);
			float px = point.x;
			float py = point.y; 
			fwrite(&px, sizeof(FLOAT), 1, f);
			fwrite(&py, sizeof(FLOAT), 1, f);
		}
	}
}

void Shape::_initAttributes()
{
	m_pRenderTarget = g_pRenderTarget;

	mPathGeometry = nullptr;
	mRectangleGeometry = nullptr;
	mEllipseGeometry = nullptr;
	m_pStrokeBrush = nullptr;
	m_pFillBrush = nullptr;
	m_selectionBrush = nullptr;
	m_whiteBrush = nullptr;
	m_pStrokeStyleCustomOffsetZero = nullptr;
	m_pLineStrokeStyle = nullptr;
	mSelected = false;
	mFirstDraw = true;
	mOnCreation = false;
}

void Shape::_createCommonObjects()
{
	HRESULT hr = S_OK;

	// Create selection brushes
	hr = m_pRenderTarget->CreateSolidColorBrush(
		GdiToColorF(D2D1::ColorF::Black),  
        &m_selectionBrush
        );

	hr = m_pRenderTarget->CreateSolidColorBrush(
		GdiToColorF(D2D1::ColorF::White),  
        &m_whiteBrush
        );

	// Create dash styles used in selection
	float dashes[] = {2.0f, 2.0f, 2.0f, 2.0f, 2.0f, 2.0f};

    hr = g_pD2DFactory->CreateStrokeStyle(
        D2D1::StrokeStyleProperties(
            D2D1_CAP_STYLE_FLAT,
            D2D1_CAP_STYLE_FLAT,
            D2D1_CAP_STYLE_ROUND,
            D2D1_LINE_JOIN_MITER,
            10.0f,
			D2D1_DASH_STYLE_CUSTOM,
            0.0f),
        dashes,
        ARRAYSIZE(dashes),
        &m_pStrokeStyleCustomOffsetZero
        );


	g_pD2DFactory->CreateStrokeStyle(
	        D2D1::StrokeStyleProperties(
				D2D1_CAP_STYLE_ROUND,
				D2D1_CAP_STYLE_ROUND,
	            D2D1_CAP_STYLE_ROUND,
				D2D1_LINE_JOIN_ROUND,
	            10.0f,
				D2D1_DASH_STYLE_SOLID,
	            0.0f),
	        NULL,
	        0,
        	&m_pLineStrokeStyle
        );
}

Shape::~Shape(void)
{
	m_pRenderTarget->Release();
	m_pStrokeBrush->Release();
    m_pFillBrush->Release();
	m_selectionBrush->Release();
	m_whiteBrush->Release();
	m_pStrokeStyleCustomOffsetZero->Release();
}

void Shape::drawContent()
{
	if(mType == Renderer::OBJECT_TYPE_BRUSH)
	{
		if(mOnCreation)
		{
			for(int i=0; i<mPoints->size(); i+=2)
			{
				D2D1_POINT_2F point1 = mPoints->at(i);
				D2D1_POINT_2F point2 = mPoints->at(i+1);

				if(mStrokeType == Renderer::STROKETYPE_SOLID)
					m_pRenderTarget->DrawLine(point1, point2, m_pStrokeBrush, mStrokeWidth, m_pLineStrokeStyle);
			}
		}
		else
		{
			m_pRenderTarget->DrawGeometry(mPathGeometry, m_pStrokeBrush, mStrokeWidth, m_pLineStrokeStyle);
		}
	}
	else if(mType == Renderer::OBJECT_TYPE_RECTANGLE)
	{
		if(mFillType == Renderer::FILLTYPE_SOLID)
			m_pRenderTarget->FillRectangle(
				D2D1::RectF(mX, mY, mX + mWidth, mY + mHeight),
				m_pFillBrush);
		
		if(mStrokeType == Renderer::STROKETYPE_SOLID)
			m_pRenderTarget->DrawRectangle(
				D2D1::RectF(mX, mY, mX + mWidth, mY + mHeight),
				m_pStrokeBrush, mStrokeWidth, NULL);

		if(mRectangleGeometry != NULL) mRectangleGeometry->Release();
		g_pD2DFactory->CreateRectangleGeometry(
			D2D1::RectF((float)mX,(float)mY, (float)(mX + mWidth),(float)(mY + mHeight)),
			&mRectangleGeometry);
	}
	else if(mType == Renderer::OBJECT_TYPE_ELLIPSE)
	{
		D2D1_ELLIPSE ellipse;
		ellipse.point = D2D1::Point2F((FLOAT)(mX + mWidth/2), (FLOAT)(mY + mHeight/2));
		ellipse.radiusX = (FLOAT)mWidth/2;
		ellipse.radiusY = (FLOAT)mHeight/2;

		if(mFillType == Renderer::FILLTYPE_SOLID)
			m_pRenderTarget->FillEllipse(&ellipse,m_pFillBrush);
		if(mStrokeType == Renderer::STROKETYPE_SOLID)
			m_pRenderTarget->DrawEllipse(&ellipse,m_pStrokeBrush,mStrokeWidth);

		if(mEllipseGeometry != NULL) mEllipseGeometry->Release();
		g_pD2DFactory->CreateEllipseGeometry(ellipse, &mEllipseGeometry);
	}
	else if(mType == Renderer::OBJECT_TYPE_LINE)
	{
		if(mStrokeType == Renderer::STROKETYPE_SOLID)
			m_pRenderTarget->DrawLine(*mLineStart, *mLineEnd, m_pStrokeBrush, mStrokeWidth, m_pLineStrokeStyle);
	}

	if(mSelected) _drawSelectionOutline();
}


void Shape::setFillColor(COLORREF color)
{
}


void Shape::setStrokeColor(COLORREF color)
{
}


bool Shape::fillContainsPoint(int x, int y)
{
	if(mType == Renderer::OBJECT_TYPE_ELLIPSE)
	{
		BOOL contains;
		if(mFillType == Renderer::FILLTYPE_UNDEF)
			mEllipseGeometry->StrokeContainsPoint(D2D1::Point2F((float)x,(float)y), mStrokeWidth, NULL, NULL, &contains);
		else
			mEllipseGeometry->FillContainsPoint(D2D1::Point2F((float)x,(float)y), NULL, &contains);

		if(contains) return true;
		else return false;
	}
	else if(mType == Renderer::OBJECT_TYPE_RECTANGLE)
	{
		BOOL contains;
		if(mFillType == Renderer::FILLTYPE_UNDEF)
			mRectangleGeometry->StrokeContainsPoint(D2D1::Point2F((float)x,(float)y), mStrokeWidth, NULL, NULL, &contains);
		else
			mRectangleGeometry->FillContainsPoint(D2D1::Point2F((float)x,(float)y), NULL, &contains);

		if(contains) return true;
		else return false;
	}
	else if(mType == Renderer::OBJECT_TYPE_BRUSH)
	{
		BOOL contains;
		mPathGeometry->StrokeContainsPoint(D2D1::Point2F((float)x,(float)y), mStrokeWidth, NULL, NULL, &contains);
		if(contains) return true;
		else return false;
	}
	else if(mType == Renderer::OBJECT_TYPE_LINE)
	{
		BOOL contains;
		mPathGeometry->StrokeContainsPoint(D2D1::Point2F((float)x,(float)y), mStrokeWidth, NULL, NULL, &contains);
		if(contains) return true;
		else return false;
	}

	return false;
}


void Shape::setSeleted(bool select)
{
	mSelected = select;
}


void Shape::_drawSelectionOutline(void)
{
	D2D1_ANTIALIAS_MODE oldMode;

	oldMode = g_pRenderTarget->GetAntialiasMode();
	//g_pRenderTarget->SetAntialiasMode(D2D1_ANTIALIAS_MODE_ALIASED);

	if(mType == Renderer::OBJECT_TYPE_LINE)
	{
		m_pRenderTarget->DrawGeometry(mPathGeometry, m_selectionBrush, 1.0, m_pStrokeStyleCustomOffsetZero);

		D2D1_RECT_F rect;
		rect.left = mX;
		rect.top = mY;
		rect.right = rect.left + 4;
		rect.bottom = rect.top + 4;

		D2D1_ELLIPSE ellipse;
		ellipse.point = D2D1::Point2F(rect.left, rect.top);
		ellipse.radiusX = 4;
		ellipse.radiusY = 4;
		m_pRenderTarget->FillEllipse(&ellipse,m_whiteBrush);
		m_pRenderTarget->DrawEllipse(&ellipse,m_selectionBrush, 1);

		rect.left = mX + mWidth;
		rect.top = mY + mHeight;
		rect.right = rect.left + 4;
		rect.bottom = rect.top + 4;

		ellipse.point = D2D1::Point2F(rect.left, rect.top);
		ellipse.radiusX = 4;
		ellipse.radiusY = 4;
		m_pRenderTarget->FillEllipse(&ellipse,m_whiteBrush);
		m_pRenderTarget->DrawEllipse(&ellipse,m_selectionBrush, 1);
	}
	else if(mType == Renderer::OBJECT_TYPE_BRUSH)
	{
		m_pRenderTarget->DrawGeometry(mPathGeometry, m_selectionBrush, 1.0, m_pStrokeStyleCustomOffsetZero);

		D2D1_RECT_F rect;
		D2D1_POINT_2F point = mPoints->at(0);
		rect.left = point.x;
		rect.top = point.y;
		rect.right = point.x + 6;
		rect.bottom = point.y + 6;

		D2D1_ELLIPSE ellipse;
		ellipse.point = D2D1::Point2F(rect.left, rect.top);
		ellipse.radiusX = 4;
		ellipse.radiusY = 4;
		m_pRenderTarget->FillEllipse(&ellipse,m_whiteBrush);
		m_pRenderTarget->DrawEllipse(&ellipse,m_selectionBrush, 1);

		int lastIndex = mPoints->size() - 1;
		point = mPoints->at(lastIndex);
		rect.left = point.x;
		rect.top = point.y;
		rect.right = point.x + 4;
		rect.bottom = point.y + 4;

		ellipse.point = D2D1::Point2F(rect.left, rect.top);
		ellipse.radiusX = 4;
		ellipse.radiusY = 4;
		m_pRenderTarget->FillEllipse(&ellipse,m_whiteBrush);
		m_pRenderTarget->DrawEllipse(&ellipse,m_selectionBrush, 1);
	}
	else
	{
		m_pRenderTarget->DrawRectangle(
				D2D1::RectF((FLOAT)mX,(FLOAT)mY,(FLOAT)(mX+mWidth),(FLOAT)(mY+mHeight)),
				m_selectionBrush, 1.0, m_pStrokeStyleCustomOffsetZero);

		float dx=3, dy=3;
		D2D1_POINT_2F points[8] = 
			{
				{mX-dx, mY-4},
				{mX + (mWidth/2) -dx, mY - dy},
				{mX + mWidth -dx, mY - dx},
				{mX + mWidth -dx, mY + (mHeight/2)},
				{mX + mWidth -dx, mY + mHeight -dy},
				{mX + (mWidth/2) -dx, mY + mHeight -dy},
				{mX -dx, mY + mHeight -dy},
				{mX -dx, mY + (mHeight/2)},
			};
		

		for(int i=0; i<8; i++)
		{
			D2D1_RECT_F rect;
			rect.left = points[i].x;
			rect.top = points[i].y;
			rect.right = points[i].x + 6;
			rect.bottom = points[i].y + 6;

			m_pRenderTarget->FillRectangle(rect, m_whiteBrush);
			m_pRenderTarget->DrawRectangle(rect, m_selectionBrush, 1, NULL);
		}
	}

	//g_pRenderTarget->SetAntialiasMode(oldMode);
}

void Shape::_createLineGeometry()
{
	HRESULT hr;

	hr = g_pD2DFactory->CreatePathGeometry(&mPathGeometry);
    ID2D1GeometrySink *pSink = NULL;
    hr = mPathGeometry->Open(&pSink);
	pSink->SetFillMode(D2D1_FILL_MODE_WINDING);

    pSink->BeginFigure(
		*mLineStart,
        D2D1_FIGURE_BEGIN_FILLED
        );

	pSink->AddLine(*mLineEnd);

    pSink->EndFigure(D2D1_FIGURE_END_OPEN);

    hr = pSink->Close();

	pSink->Release();
}

void Shape::_createBrushGeometry()
{
	HRESULT hr;

	hr = g_pD2DFactory->CreatePathGeometry(&mPathGeometry);
    ID2D1GeometrySink *pSink = NULL;
    hr = mPathGeometry->Open(&pSink);
	pSink->SetFillMode(D2D1_FILL_MODE_WINDING);

	D2D1_POINT_2F point = mPoints->at(0);
    pSink->BeginFigure(
		D2D1::Point2F(point.x,point.y),
        D2D1_FIGURE_BEGIN_FILLED
        );

	for(int i=0; i<mPoints->size(); i+=3)
	{
		D2D1_POINT_2F point1 = mPoints->at(i);

		D2D1_POINT_2F point2;
		if(mPoints->size() > i+1)
			point2 = mPoints->at(i+1);
		else
		{
			point2.x = point1.x;
			point2.y = point1.y;
		}

		D2D1_POINT_2F point3;
		if(mPoints->size() > i+2)
			point3 = mPoints->at(i+2);
		else
		{
			point3.x = point2.x;
			point3.y = point2.y;
		}
		
		pSink->AddBezier(
               D2D1::BezierSegment(
			   		point1,
           			point2,
                   	point3
                   ));

		//D2D1_POINT_2F point = mPoints[i];
		//pSink->AddLine(point);
	}

    pSink->EndFigure(D2D1_FIGURE_END_OPEN);

    hr = pSink->Close();

	pSink->Release();
}

void Shape::createStart(int x, int y)
{
	if(mType == Renderer::OBJECT_TYPE_LINE)
	{
		mLineStart = new D2D1_POINT_2F;
		mLineEnd = new D2D1_POINT_2F;
	}
	else if(mType == Renderer::OBJECT_TYPE_RECTANGLE)
	{
		mX = x;
		mY = y;
	}
	else if(mType == Renderer::OBJECT_TYPE_ELLIPSE)
	{
		mX = x;
		mY = y;
	}
	else if(mType == Renderer::OBJECT_TYPE_BRUSH)
	{
		if(mFirstDraw)
		{
			mOldX = x;
			mOldY = y;
			mFirstDraw = false;
		}
	}

	mOnCreation = true;
}


void Shape::createProcessing(int x, int  y)
{
	if(mType == Renderer::OBJECT_TYPE_BRUSH)
	{
		D2D1_POINT_2F p1;
		p1.x = mOldX;
		p1.y = mOldY;
		mPoints->push_back(p1);

		D2D1_POINT_2F p2;
		p2.x = x;
		p2.y = y;
		mPoints->push_back(p2);

		mOldX = x;
		mOldY = y;
	}
	else if(mType == Renderer::OBJECT_TYPE_RECTANGLE)
	{
		mWidth = x - mX;
		mHeight = y - mY;
	}
	else if(mType == Renderer::OBJECT_TYPE_LINE)
	{
		mWidth = x - mX;
		mHeight = y - mY;

		mLineStart->x = mX;
		mLineStart->y = mY;

		mLineEnd->x = mX + mWidth;
		mLineEnd->y = mY + mHeight;
	}
	else if(mType == Renderer::OBJECT_TYPE_ELLIPSE)
	{
		mWidth = x - mX;
		mHeight = y - mY;
	}
}

void Shape::createEnd(int x, int y)
{
	if(mType == Renderer::OBJECT_TYPE_LINE) _createLineGeometry();
	else if(mType == Renderer::OBJECT_TYPE_BRUSH) _createBrushGeometry();

	mOnCreation = false;
}


void Shape::moveRel(int relX, int relY)
{
	if(mType == Renderer::OBJECT_TYPE_LINE)
	{
		mX += relX;
		mY += relY;

		mLineStart->x += relX;
		mLineStart->y += relY;

		mLineEnd->x += relX;
		mLineEnd->y += relY;

		mPathGeometry->Release();
		_createLineGeometry();
	}
	else if(mType == Renderer::OBJECT_TYPE_BRUSH)
	{
		vector<D2D1_POINT_2F> *vpoints = new vector<D2D1_POINT_2F>;

		mX += relX;
		mY += relY;
		for(int i=0; i<mPoints->size(); i++)
		{
			D2D1_POINT_2F point = mPoints->at(i);
			
			D2D1_POINT_2F point1;
			point1.x = point.x + relX;
			point1.y = point.y + relY;
			vpoints->push_back(point1);
		}
		delete mPoints;
		mPoints = vpoints;

		mPathGeometry->Release();
		_createBrushGeometry();
	}
	else
	{
		mX += relX;
		mY += relY;
	}
}
